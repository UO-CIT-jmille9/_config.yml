// Require the Fastify framework and instantiate it
const fastify = require("fastify")({
    logger: false,
    });
    // Handle GET verb for / route using Fastify
    // Note use of "chain" dot notation syntax
    fastify.get("/", (request, reply) => {
    reply
    .code(200)
    .header("Content-Type", "text/html; charset=utf-8")
    .send("<h1>Hello from Fastify!</h1>");
    });
    // Start server and listen to requests using Fastify
    const listenIP = 'localhost';
    const listenPort = 8082;
    fastify.listen(listenPort, listenIP, (err, address) => {
    if (err) {
    // fastify.log.error(err);
    console.log(err);
    process.exit(1);
    }
    // fastify.log.info(`Server listening on ${address}`);
    console.log(`Server listening on ${address}`);
    });

    // Student array
    const students = [
        {
          id: 1,
          last: "Last1",
          first: "First1",
        },
        {
          id: 2,
          last: "Last2",
          first: "First2",
        },
        {
          id: 3,
          last: "Last3",
          first: "First3",
        }
      ];


// define GET route to return all students
fastify.get('/cit/student', (req, res) => {
  res.status(200).json(students);
});

// define GET route to return a single student by id
fastify.get('/cit/student/:id', (req, res) => {
  const id = parseInt(req.params.id);
  for (const student of students) {
    if (student.id === id) {
      return res.status(200).json(student);
    }
  }
  res.status(404).send('Not Found');
});

// define unmatched route handler
fastify.get('*', (req, res) => {
  res.status(404).send('Not Found');
});

// start the server
fastify.listen(3000, () => {
  console.log('Server started on port 3000');
});
