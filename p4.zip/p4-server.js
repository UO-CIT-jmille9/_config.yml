const fastify = require("fastify")();

const {
  getQuestions,
  getAnswers,
  getQuestionsAnswers,
  getQuestion,
  getAnswer,
  getQuestionAnswer,
  addQuestionAnswer,
} = require("./p4-module");

fastify.get("/cit/question", (request, reply) => {
  reply.send({ error: "", statusCode: 200, questions: getQuestions() });
});

fastify.get("/cit/answer", (request, reply) => {
  reply.send({ error: "", statusCode: 200, answers: getAnswers() });
});

fastify.get("/cit/questionanswer", (request, reply) => {
  reply.send({ error: "", statusCode: 200, questions_answers: getQuestionsAnswers() });
});

fastify.get("/cit/question/:number", (request, reply) => {
  const number = Number(request.params.number);
  const { error, statusCode, ...data } = getQuestion(number);
  reply.send({ error, statusCode, question: data.question, number: data.number });
});

fastify.get("/cit/answer/:number", (request, reply) => {
  const number = Number(request.params.number);
  const { error, statusCode, ...data } = getAnswer(number);
  reply.send({ error, statusCode, answer: data.answer, number: data.number });
});

fastify.get("/cit/questionanswer/:number", (request, reply) => {
  const number = Number(request.params.number);
  const { error, statusCode, ...data } = getQuestionAnswer(number);
});
  reply.send({
    error,
    statusCode,
    question: data.question,
    answer: data.answer,
    number: data.number
  });

  // Extra Credit: Added support for PUT requests
  fastify.put('/cit/question', (req, res) => {
    const { number, question, answer } = req.body;
  
    if (!number || !question || !answer) {
      return res.status(400).json({ error: 'Invalid request body' });
    }
  
    const result = updateQuestionAnswer({ number, question, answer });
  
    if (result.error) {
      return res.status(400).json(result);
    }
  
    return res.json(result);
  });

  //Extra Credit: Added support for DELETE requests
  fastify.delete('/cit/question/:number', (req, res) => {
    const number = parseInt(req.params.number);
  
    if (isNaN(number)) {
      return res.status(400).json({ error: 'Invalid question number' });
    }
  
    const result = deleteQuestionAnswer(number);
  
    if (result.error) {
      return res.status(400).json(result);
    }
  
    return res.json(result);
  });